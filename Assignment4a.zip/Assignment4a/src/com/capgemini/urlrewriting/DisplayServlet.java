package com.capgemini.urlrewriting;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DisplayServlet
 */
public class DisplayServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DisplayServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		 String pincode=request.getParameter("pincode");
		  String city=null; 
		  String technology=request.getParameter("technology");
		  String userName=request.getParameter("username");
		  out.println("<h6>userName="+userName+"</h6>");
		  out.println("<h6>pincode="+pincode+"</h6>");
		  out.println("<h6>technnology known="+technology+"</h6>");
		  if(pincode.equals("244221"))
			  city="Amroha";
		  else
			  if(pincode.equals("244251")){ 
				  city="Gajrola"; 
				  } 
			  else 
				  city="Unknown";
		  if(city.equals("Amroha")&&(technology.equals("java") || technology.equals("python"))){
			  out.println("AI Job");
		  }else {
			  if(city.equals("Gajrola")&&(technology.equals("angular") ||technology.equals("java"))) {
				  out.println("web Developer"); 
				  
			  } 
		}
	}

}
